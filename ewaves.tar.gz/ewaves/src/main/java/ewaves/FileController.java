package ewaves;

import ewaves.util.UploadFileResponse;
import ewaves.util.FileStorageService;
import industries.doublehelix.image2sound.Worker;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ColorModel;
import java.awt.image.DirectColorModel;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;
import java.io.File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.bind.annotation.ModelAttribute;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import javax.imageio.ImageIO;
import org.springframework.beans.factory.annotation.Value;

@RestController
public class FileController {

    private static final Logger logger = LoggerFactory.getLogger(FileController.class);

    @Autowired
    private FileStorageService fileStorageService;

    public static Image convertColorImgToGrayscale(Image coloredImg) {
        try {
            PixelGrabber grabber = new PixelGrabber(coloredImg, 0, 0, -1, -1, false);

            if (grabber.grabPixels()) {
                int width = grabber.getWidth();
                int height = grabber.getHeight();

                if (grabber.getPixels() instanceof byte[]) {
                    System.out.println("bow wow wow wow wow hah... NINE CORONAS!");
                    return coloredImg;
                }

                // farbiges bild, convertieren zu graustufe
                int[] color = (int[]) grabber.getPixels();
                byte[] greyscale = new byte[color.length];
                for (int i = 0; i < color.length; ++i) {
                    // http://schmidt.devlib.org/java/image-faq/argb-pixel-encoding.html
                    int red = (color[i] >> 16) & 0xff;
                    int green = (color[i] >> 8) & 0xff;
                    int blue = color[i] & 0xff;
                    //E = .31R + .59G + .10B
                    greyscale[i] = (byte) ((red * 0.31) + (green * 0.59) + (blue * 0.1));

                    // ich hab keine ahnung, WARUM das geht, aber der blauwert eines Color-Objektes
                    // aus new Color(greyscale[i]), genommen als wert f�r r, g und b, ergiebt das konvertierte
                    // grau..
                }

                // construct a ColorModel for the gray scale
                ColorModel cm = new DirectColorModel(8, 255, 255, 255);
                // construct a MemoryImageSource that can be used to create the image
                MemoryImageSource mis = new MemoryImageSource(width, height, cm, greyscale, 0, width);

                // in a component class you can use createImage directly
                return Toolkit.getDefaultToolkit().createImage(mis);
            }
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
        return null;
    }

    @Value("${file.upload-dir}")
    private String uploaddir;

    @PostMapping("/uploadFile")
    public UploadFileResponse uploadFile(@ModelAttribute ModelDTO modeldto) throws IOException {

//    public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file, @RequestBody Map<String, String> payload) throws IOException {
        MultipartFile file = modeldto.file;
        String fileName = fileStorageService.storeFile(file);
        String wavfiname = fileName + ".wav";
        File wav = new File(uploaddir + wavfiname);

        if (modeldto.minfreq == null) {
            modeldto.minfreq = 65;
        }
        if (modeldto.maxfreq == null) {
            modeldto.maxfreq = 16000;
        }
        if (modeldto.algo == null) {
            modeldto.algo = "log";
        }
        if (modeldto.sample == null) {
            modeldto.sample = 44100;
        }
        System.out.printf("all payload: %s", modeldto);

        Image image = ImageIO.read(fileStorageService.loadFileAsResource(fileName).getInputStream());
        image = convertColorImgToGrayscale(image);
        boolean log = false;
        if ("log".equals(modeldto.algo)) {
            log = true;
        }
        Worker work = new Worker(null, image, wav, log,
                modeldto.minfreq, modeldto.maxfreq,
                modeldto.sample, modeldto.time);

        work.run();

        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(wavfiname)
                .toUriString();

        return new UploadFileResponse(fileName, fileDownloadUri,
                "audio/wav", file.getSize());
    }

    @GetMapping("/downloadFile/{fileName:.+}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
        // Load file as Resource
        Resource resource = fileStorageService.loadFileAsResource(fileName);

        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            logger.info("Could not determine file type.");
        }

        // Fallback to the default content type if type could not be determined
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

}
