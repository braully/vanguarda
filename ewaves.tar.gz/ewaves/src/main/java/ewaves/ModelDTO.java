/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ewaves;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author strike
 */
public class ModelDTO {

    String algo;

    Integer sample, minfreq, maxfreq, time;

    MultipartFile file;

    @Override
    public String toString() {
        return "ModelDTO{" + "sample=" + sample + ", algo=" + algo + ", minfreq=" + minfreq + ", maxfreq=" + maxfreq + ", time=" + time + ", file=" + file + '}';
    }

    public Integer getSample() {
        return sample;
    }

    public void setSample(Integer sample) {
        this.sample = sample;
    }

    public String getAlgo() {
        return algo;
    }

    public void setAlgo(String algo) {
        this.algo = algo;
    }

    public Integer getMinfreq() {
        return minfreq;
    }

    public void setMinfreq(Integer minfreq) {
        this.minfreq = minfreq;
    }

    public Integer getMaxfreq() {
        return maxfreq;
    }

    public void setMaxfreq(Integer maxfreq) {
        this.maxfreq = maxfreq;
    }

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

}
