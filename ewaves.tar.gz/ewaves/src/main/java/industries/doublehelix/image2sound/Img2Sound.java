package industries.doublehelix.image2sound;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ColorModel;
import java.awt.image.DirectColorModel;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import info.clearthought.layout.TableLayout;

public class Img2Sound implements ActionListener {

    public JFrame frmAll = new JFrame("Image2Sound - Double Helix Industries");
    public ImagePanel imgPnl = new ImagePanel();
    public ConfigPanel cnfPnl = new ConfigPanel();
    public File actualFile;
    public String pathToWav;

    public static void main(String[] args) {
        new Img2Sound();
    }

    public Img2Sound() {
        double[][] size = {{TableLayout.FILL, 5, TableLayout.PREFERRED}, {TableLayout.FILL}};
        JPanel pnl = new JPanel(new TableLayout(size));
        pnl.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        pnl.add(imgPnl, "0, 0");
        pnl.add(cnfPnl, "2, 0");
        frmAll.add(pnl);

        frmAll.setSize(700, 500);
        frmAll.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmAll.setLocationRelativeTo(null);
        frmAll.setVisible(true);

        cnfPnl.addButtonActionListener(this);
    }

    public void actionPerformed(ActionEvent a) {
        if (a.getActionCommand().equals("LOADIMG")) {
            //File folder = jfcBmpChooser.getCurrentDirectory();

            //jfcBmpChooser = new JFileChooser(folder);
            String folder = (actualFile == null) ? null : actualFile.getParent();
            JFileChooser jfcBmpChooser = new JFileChooser(folder);
            FileFilter imageFilter = new FileNameExtensionFilter("Image files", ImageIO.getReaderFileSuffixes());
            jfcBmpChooser.setFileFilter(imageFilter);
            int answer = jfcBmpChooser.showOpenDialog(frmAll);
            if (answer != JFileChooser.APPROVE_OPTION) {
                return;
            }
            File file = jfcBmpChooser.getSelectedFile();
            if (file.isDirectory() || !file.exists()) {
                return;
            }

            boolean wrongFileType = true;
            for (String ext : ImageIO.getReaderFileSuffixes()) {
                if (file.getName().toLowerCase().endsWith("." + ext)) {
                    wrongFileType = false;
                    break;
                }
            }
            if (wrongFileType) {
                JOptionPane.showMessageDialog(frmAll, "Only image files", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Image img = null;
            try {
                img = ImageIO.read(file);
                img = convertColorImgToGrayscale(img);
            } catch (Exception e) {
                e.printStackTrace();
                // uh oh
                JOptionPane.showMessageDialog(frmAll, "Could not read image: " + e.toString(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            imgPnl.setImage(img);
            actualFile = file;
            cnfPnl.setContentEnabled(true);
        } else if (a.getActionCommand().equals("GENERATE")) {
            // jetzt wird's interessant
            String folder = (actualFile == null) ? null : actualFile.getParent();
            JFileChooser jfcWavChooser = new JFileChooser(folder);
            jfcWavChooser.setFileFilter(new FileFilter() {
                public boolean accept(File arg0) {
                    if (arg0.isDirectory()) {
                        return true;
                    }
                    return arg0.getName().toLowerCase().endsWith(".wav");
                }

                public String getDescription() {
                    return "Wave-Dateien (.wav)";
                }
            });
            int answer = jfcWavChooser.showSaveDialog(frmAll);
            if (answer != JFileChooser.APPROVE_OPTION) {
                return;
            }
            File wav = jfcWavChooser.getSelectedFile();
            if (wav.isDirectory()) {
                return;
            }
            if (!wav.getName().toLowerCase().endsWith(".wav")) {
                wav = new File(wav.getAbsolutePath() + ".wav");
            }
            if (wav.exists()) {
                int bla = JOptionPane.showConfirmDialog(frmAll, "File exists already. Overwrite?", "Exists", JOptionPane.YES_NO_OPTION);
                if (bla == JOptionPane.NO_OPTION) {
                    return;
                }
            }
            //cnfPnl;
            pathToWav = wav.getAbsolutePath();
            System.out.printf("Parametros: log %s,  %s, %s, %s, %s ",
                    cnfPnl.isLogSelected(), cnfPnl.getMinFreq(), cnfPnl.getMaxFreq(),
                     cnfPnl.getSampleFreq(), cnfPnl.getTime());
            Worker work = new Worker(frmAll, imgPnl.getImage(), wav, cnfPnl.isLogSelected(),
                    cnfPnl.getMinFreq(), cnfPnl.getMaxFreq(), cnfPnl.getSampleFreq(), cnfPnl.getTime());
            final Thread t = new Thread(work);
            t.start();

            // thread for catching the finish
            new Thread(new Runnable() {
                public void run() {
                    try {
                        t.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    JOptionPane.showMessageDialog(frmAll, "Finished!\nReminder: " + pathToWav, "Finished", JOptionPane.INFORMATION_MESSAGE);
                    if (cnfPnl.isListenSelected()) {
                        new AePlayWave(pathToWav).run();
                    }
                }
            }).start();
        }
    }

    public void setConfigPanelEnabled(boolean b) {
        cnfPnl.setEverythingEnabled(b);
    }

    public static Image convertColorImgToGrayscale(Image coloredImg) {
        try {
            PixelGrabber grabber = new PixelGrabber(coloredImg, 0, 0, -1, -1, false);

            if (grabber.grabPixels()) {
                int width = grabber.getWidth();
                int height = grabber.getHeight();

                if (grabber.getPixels() instanceof byte[]) {
                    System.out.println("bow wow wow wow wow hah... NINE CORONAS!");
                    return coloredImg;
                }

                // farbiges bild, convertieren zu graustufe
                int[] color = (int[]) grabber.getPixels();
                byte[] greyscale = new byte[color.length];
                for (int i = 0; i < color.length; ++i) {
                    // http://schmidt.devlib.org/java/image-faq/argb-pixel-encoding.html
                    int red = (color[i] >> 16) & 0xff;
                    int green = (color[i] >> 8) & 0xff;
                    int blue = color[i] & 0xff;
                    //E = .31R + .59G + .10B
                    greyscale[i] = (byte) ((red * 0.31) + (green * 0.59) + (blue * 0.1));

                    // ich hab keine ahnung, WARUM das geht, aber der blauwert eines Color-Objektes
                    // aus new Color(greyscale[i]), genommen als wert f�r r, g und b, ergiebt das konvertierte
                    // grau..
                }

                // construct a ColorModel for the gray scale
                ColorModel cm = new DirectColorModel(8, 255, 255, 255);
                // construct a MemoryImageSource that can be used to create the image
                MemoryImageSource mis = new MemoryImageSource(width, height, cm, greyscale, 0, width);

                // in a component class you can use createImage directly
                return Toolkit.getDefaultToolkit().createImage(mis);
            }
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
        return null;
    }

}
