package industries.doublehelix.image2sound;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JScrollPane;


public class ImagePanel extends JScrollPane {
	private static final long serialVersionUID = 1023022354818505761L;
	JLabel m_imageLabel = new JLabel();
	Image m_image;
	
	ImagePanel() {
		m_imageLabel.setHorizontalAlignment(JLabel.CENTER);
		this.setViewportView(m_imageLabel);
	}
	
	public void setImage(Image img) {
		m_image = img;
		m_imageLabel.setIcon(new ImageIcon(m_image));
	}
	
	public Image getImage() {
		return m_image;
	}
}
