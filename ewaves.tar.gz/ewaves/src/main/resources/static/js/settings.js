function abrirModal() {
    let modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('modal'));
    modal.show();
}

function fecharModal() {
    let modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('modal'));
    modal.hide();
}

setTimeout(function(){
    $(".page-loader").fadeOut();
}, 1800);

function initall() {
    $("#myAudioElement").hide();
    $("#btn-baixar").hide();
    $('#btn-gerar').show();
    $('#txt-btn-gerar').html("GERAR ÁUDIO");
    $('#btn-gerar').prop("disabled", false);
    $('#singleUploadForm').show();
}

function imagemCarregada() {
    $('#btn-upload').html('<i class="material-icons">check</i>');
    $('#ellipse').addClass("ellipse-carregada");
    initall();
}

function geraraudio() {
    $('#btn-gerar').prop("disabled", true);
    $('#txt-btn-gerar').html("AGUARDE");
}

function audiogerado(fileDownloadUri) {
    $('#btn-gerar').hide();
    $('#btn-baixar').show();
    $('#singleUploadForm').hide();
    $("#myAudioElement").show();
    $("#dlink").attr("href", fileDownloadUri);
    audioPlayer(fileDownloadUri);
    $('#btn-upload').html('<span class="material-icons">reply</span> <h6 class="voltar-btn">Voltar</h6>');
    $('#btn-upload').attr("onclick", "");
    $('#btn-upload').addClass("reniciar");
}

$(document).on("click", "#btn-upload.reniciar" ,function(){
    window.location.reload();
})

function setImageFromDataURL(dataurl) {
    var filename = $('#singleFileUploadInput').val().split('\\').pop();
    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[arr.length - 1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    nfile = new File([u8arr], filename, { type: mime });
    console.log(nfile);
    var dataTransfer = new DataTransfer();
    dataTransfer.items.add(nfile);
    $('#cropedImage')[0].files = dataTransfer.files;
}

function getRoundedCanvas(sourceCanvas) {
    var canvas = document.createElement('canvas');
    var context = canvas.getContext('2d');
    var width = sourceCanvas.width;
    var height = sourceCanvas.height;

    canvas.width = width;
    canvas.height = height;
    context.imageSmoothingEnabled = true;
    context.drawImage(sourceCanvas, 0, 0, width, height);
    context.globalCompositeOperation = 'destination-in';
    context.beginPath();
    context.fill();
    return canvas;
}

window.addEventListener('DOMContentLoaded', function () {
    $('#btn-gerar').prop("disabled", true);

    var image = document.getElementById('image');
    var button = document.getElementById('btn-cortar');
    var result = document.getElementById('result');
    var croppable = false;

    var cropBoxData;
    var canvasData;
    var cropper;

    $('#modal').on('shown.bs.modal',
        function () {
            cropper = new Cropper(image, {
                initialAspectRatio: 16 / 9,
                autoCropArea: 0.7,
                dragMode: 'move',
                ready: function () {
                    croppable = true;
                },
            });
        }).on('hidden.bs.modal',
            function () {
                cropBoxData = cropper.getCropBoxData();
                canvasData = cropper.getCanvasData();
                cropper.destroy();
            });

    let lastValue = parseInt(rotateRange.value);

    rotateRange.addEventListener('input', function () {
        let currentValue = parseInt(this.value);
        let difference = currentValue - lastValue;
        cropper.rotate(difference);
        lastValue = currentValue;
    });

    button.onclick = function () {
        if (!croppable) {
            return;
        }

        var croppedCanvas = cropper.getCroppedCanvas();
        var roundedCanvas = getRoundedCanvas(croppedCanvas);

        src = cv.imread(roundedCanvas);
        dst = new cv.Mat();
        cv.cvtColor(src, src, cv.COLOR_RGBA2GRAY, 0);
        cv.threshold(src, dst, 130, 255, cv.THRESH_BINARY);
        cv.imshow(roundedCanvas, dst);
        src.delete();
        dst.delete();

        var roundedImage = document.createElement('img');
        roundedImage.src = roundedCanvas.toDataURL();
        result.innerHTML = '';
        result.appendChild(roundedImage);

        setImageFromDataURL(roundedCanvas.toDataURL());
        imagemCarregada();
        fecharModal();
    };
});

$('#singleFileUploadInput').on('change', function () {
    if (this.files && this.files[0]) {
        if (this.files[0].type.match(/^image\//)) {
            var imageFile = this.files[0];
            var url = window.URL.createObjectURL(imageFile);
            var image = document.getElementById('image');
            image.src = url;

            abrirModal();
        }
    }
});

const value = document.querySelector("#value-tempo");
const input = document.querySelector("#tempo");
value.textContent = input.value;
input.addEventListener("input", (event) => {
    value.textContent = event.target.value;
});

var singleUploadForm = document.querySelector('#singleUploadForm');
var singleFileUploadInput = document.querySelector('#cropedImage');
var singleFileUploadError = document.querySelector('#singleFileUploadError');
var singleFileUploadSuccess = document.querySelector('#singleFileUploadSuccess');

function uploadSingleFile(file) {
    var formData = new FormData(singleUploadForm);
    formData.append("file", file);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/uploadFile");

    xhr.onload = function () {
        console.log(xhr.responseText);
        var response = JSON.parse(xhr.responseText);
        if (xhr.status == 200) {
            singleFileUploadError.style.display = "none";
            singleFileUploadSuccess.innerHTML = "<p>File Uploaded Successfully.</p><p>DownloadUrl : <a href='" + response.fileDownloadUri + "' target='_blank'>" + response.fileDownloadUri + "</a></p>";
            singleFileUploadSuccess.style.display = "block";

            try {
                audiogerado(response.fileDownloadUri);
            } catch (err) {
            }
        } else {
            singleFileUploadSuccess.style.display = "none";
            singleFileUploadError.innerHTML = (response && response.message) || "Some Error Occurred";
        }
    }

    xhr.send(formData);
}

singleUploadForm.addEventListener('submit', function (event) {
    var files = singleFileUploadInput.files;
    if (files.length === 0) {
        singleFileUploadError.innerHTML = "Please select a file";
        singleFileUploadError.style.display = "block";
    }
    $('#btn-upload').html("<span class='material-icons generatingIcon rotate'>sync</span>");
    geraraudio();
    uploadSingleFile(files[0]);
    event.preventDefault();
}, true);
initall();

function adjustHeight() {
    if (window.innerWidth < 630) {
        var viewportHeight = window.innerHeight;
        var headerHeight = 0;
        var contentHeight = viewportHeight - headerHeight;
        document.querySelector('.modal-content').style.height = contentHeight + 'px';
    } else {
        document.querySelector('.modal-content').style.height = 'auto';
    }
}

window.addEventListener('resize', adjustHeight);
window.addEventListener('load', adjustHeight);

function audioPlayer(url) {
    const audioPlayer = document.querySelector(".audio-player");
    const audio = new Audio(url);
    audio.play();

    audio.addEventListener("loadeddata", () => {
        audioPlayer.querySelector(".time .length").textContent = getTimeCodeFromNum(audio.duration);
        audio.volume = .75;
    }, false);

    const timeline = audioPlayer.querySelector(".timeline");
    timeline.addEventListener("click", e => {
        const timelineWidth = window.getComputedStyle(timeline).width;
        const timeToSeek = e.offsetX / parseInt(timelineWidth) * audio.duration;
        audio.currentTime = timeToSeek;
    }, false);

    const volumeSlider = audioPlayer.querySelector(".controls .volume-slider");
    volumeSlider.addEventListener('click', e => {
        const sliderWidth = window.getComputedStyle(volumeSlider).width;
        const newVolume = e.offsetX / parseInt(sliderWidth);
        audio.volume = newVolume;
        audioPlayer.querySelector(".controls .volume-percentage").style.width = newVolume * 100 + '%';
    }, false)

    setInterval(() => {
        const progressBar = audioPlayer.querySelector(".progress_player");
        progressBar.style.width = audio.currentTime / audio.duration * 100 + "%";
        audioPlayer.querySelector(".time .current").textContent = getTimeCodeFromNum(audio.currentTime);
    }, 50);

    const playBtn = audioPlayer.querySelector(".controls .toggle-play");
    playBtn.addEventListener("click", () => {
        if (audio.paused) {
            playBtn.classList.remove("play");
            playBtn.classList.add("pause");
            audio.play();
        } else {
            playBtn.classList.remove("pause");
            playBtn.classList.add("play");
            audio.pause();
        }
    }, false);

    audio.addEventListener('ended', function () {
        playBtn.classList.remove("pause");
        playBtn.classList.add("play");
    });

    audioPlayer.querySelector(".volume-button").addEventListener("click", () => {
        const volumeEl = audioPlayer.querySelector(".volume-container .volume");
        audio.muted = !audio.muted;
        if (audio.muted) {
            volumeEl.classList.remove("icono-volumeMedium");
            volumeEl.classList.add("icono-volumeMute");
        } else {
            volumeEl.classList.add("icono-volumeMedium");
            volumeEl.classList.remove("icono-volumeMute");
        }
    });

    function getTimeCodeFromNum(num) {
        let seconds = parseInt(num);
        let minutes = parseInt(seconds / 60);
        seconds -= minutes * 60;
        const hours = parseInt(minutes / 60);
        minutes -= hours * 60;

        if (hours === 0) return `${minutes}:${String(seconds % 60).padStart(2, 0)}`;
        return `${String(hours).padStart(2, 0)}:${minutes}:${String(seconds % 60).padStart(2, 0)}`;
    }
}
